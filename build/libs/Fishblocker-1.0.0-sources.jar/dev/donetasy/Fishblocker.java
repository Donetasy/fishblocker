package dev.donetasy;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1536;
import net.minecraft.class_2561;

public class Fishblocker implements ModInitializer {

    private boolean debugEnabled = false;


    private int stableTicks = 0;
    private boolean armed = false;
    private int waitTicks = 0;
    private boolean recastPending = false;
    private class_1536 lastHook = null;
    private double Ydrop = 0.03;

    private double Sensitivity = 0.015;

    private double cfgSensitivity = 0.015;

    private double cfgYdrop = 0.03;


    private int cfgStableTicks = 1;


    private int cfgWaitCatch = 20;


    private int cfgWaitRecast = 15;

    @Override
    public void onInitialize() {

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("fishblocker")
                    // /fishblocker toggle
                    .then(ClientCommandManager.literal("toggle")
                            .executes(context -> {
                                debugEnabled = !debugEnabled;
                                context.getSource().getPlayer().method_7353(
                                        class_2561.method_43470("§7[Fishblocker] Auto-Fisher " + (debugEnabled ? "§aActive" : "§cDeactivated")),
                                        false
                                );
                                return 1;
                            })
                    )
                    // /fishblocker config
                    .then(ClientCommandManager.literal("config")
                            // /fishblocker config stableTicks <int>
                            .then(ClientCommandManager.literal("stableTicks")
                                    .then(ClientCommandManager.argument("wert", IntegerArgumentType.integer(1))
                                            .executes(context -> {
                                                cfgStableTicks = IntegerArgumentType.getInteger(context, "wert");
                                                context.getSource().getPlayer().method_7353(
                                                        class_2561.method_43470("§a[Fishblocker] set StableTick to  " + cfgStableTicks + " Ticks."), false);
                                                return 1;
                                            })
                                    )
                            )
                            // /fishblocker config waitCatch <int>
                            .then(ClientCommandManager.literal("waitCatch")
                                    .then(ClientCommandManager.argument("wert", IntegerArgumentType.integer(0))
                                            .executes(context -> {
                                                cfgWaitCatch = IntegerArgumentType.getInteger(context, "wert");
                                                context.getSource().getPlayer().method_7353(
                                                        class_2561.method_43470("§a[Fishblocker] Set WaitCatch to " + cfgWaitCatch + " Ticks ."), false);
                                                return 1;
                                            })
                                    )
                            )
                            // /fishblocker config waitRecast <int>
                            .then(ClientCommandManager.literal("waitRecast")
                                    .then(ClientCommandManager.argument("wert", IntegerArgumentType.integer(0))
                                            .executes(context -> {
                                                cfgWaitRecast = IntegerArgumentType.getInteger(context, "wert");
                                                context.getSource().getPlayer().method_7353(
                                                        class_2561.method_43470("§a[Fishblocker] Set WaitRecast to " + cfgWaitRecast + " Ticks."), false);
                                                return 1;
                                            })
                                    )
                            )
                            // /fishblocker config Sensitivity <double>
                            .then(ClientCommandManager.literal("Sensitivity")
                                    .then(ClientCommandManager.argument("double", DoubleArgumentType.doubleArg(0.0))
                                            .executes(context -> {
                                                cfgSensitivity = DoubleArgumentType.getDouble(context, "double");
                                                context.getSource().getPlayer().method_7353(
                                                        class_2561.method_43470("§a[Fishblocker] Set Sensitivity to " + cfgSensitivity + " Y movement."),
                                                        false
                                                );
                                                return 1;
                                            })
                                    )
                            )
                            // /fishblocker config Ydrop <double>
                            .then(ClientCommandManager.literal("Ydrop")
                                    .then(ClientCommandManager.argument("double", DoubleArgumentType.doubleArg(0.0))
                                            .executes(context -> {
                                                cfgYdrop = DoubleArgumentType.getDouble(context, "double");
                                                context.getSource().getPlayer().method_7353(
                                                        class_2561.method_43470("§a[Fishblocker] Set Ydrop to " + cfgYdrop + " Y movement."),
                                                        false
                                                );
                                                return 1;
                                            })
                                    )
                            )
                    )
            );
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {

            if (client.field_1724 == null) return;

            if (recastPending) {
                if (waitTicks > 0) {
                    waitTicks--;
                } else {
                    client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                    recastPending = false;
                    waitTicks = cfgWaitRecast;
                }
                return;
            }

            if (waitTicks > 0) {
                waitTicks--;
                return;
            }

            class_1536 bobber = client.field_1724.field_7513;

            if (debugEnabled) {
                String debugMsg = "§eno rod thrown";

                if (bobber != null) {
                    double currentMotionY = bobber.method_18798().field_1351;
                    debugMsg = "armed=" + armed + " | stableTicks=" + stableTicks +
                            " | motionY=" + String.format("%.3f", currentMotionY);
                }

                client.field_1724.method_7353(class_2561.method_43470(debugMsg), true);
            }

            if (bobber == null) {
                lastHook = null;
                armed = false;
                stableTicks = 0;
                return;
            }

            if (lastHook != bobber) {
                lastHook = bobber;
                armed = false;
                stableTicks = 0;
            }

            boolean inFluid = bobber.method_5799() || bobber.method_5771();
            double motionY = bobber.method_18798().field_1351;


            boolean stable = inFluid && Math.abs(motionY) < Sensitivity;
            boolean drop = motionY < -Ydrop;

            if (stable) {
                stableTicks++;

                if (stableTicks >= cfgStableTicks) {
                    armed = true;
                }
            } else {
                stableTicks = 0;
            }

            if (armed && drop && debugEnabled) {
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);

                client.field_1724.method_7353(
                        class_2561.method_43470("§a[fishblocker] hook"),
                        false
                );

                armed = false;
                stableTicks = 0;
                lastHook = null;

                recastPending = true;
                waitTicks = cfgWaitCatch;
            }
        });
    }
}